from sklearn.datasets import load_iris
from BoxPlotMaker import BoxPlotMaker
import os
import time

# get iris dataset
X_class, y_class = load_iris().data, load_iris().target

# we just want binary classification
X_class = X_class[:100]
y_class = y_class[:100]

# separate classes
X_class_1 = X_class[:50]
y_class_1 = y_class[:50]
X_class_2 = X_class[50:]
y_class_2 = y_class[50:]


boxPlotMaker = BoxPlotMaker()

os.chdir(
    "c:\\Users\\swart\\Desktop\\secure-mpc-main\\distance_graphs\\box_plots\\box_plots_iris"
)

# print(boxPlotMaker._get_avg_distance_arr_between_points(X_class_1, X_class_1, 9, True))

# print(boxPlotMaker._get_avg_distance_arr_between_points(X_class_1, X_class_2, 9, True))

# normal_point_x_labels = [
#     "Normal-Normal: Traditional",
#     "Normal-Normal: Secure",
#     "Normal-AF: Traditional",
#     "Normal-AF: Secure",
# ]
# af_point_x_labels = [
#     "AF-Normal: Traditional",
#     "AF-Normal: Secure",
#     "AF-AF: Traditional",
#     "AF-AF: Secure",
# ]
# normal_point_x_labels = [
#     "N-N: Traditional",
#     "N-N: Secure",
#     "N-AF: Traditional",
#     "N-AF: Secure",
# ]
# af_point_x_labels = [
#     "AF-AF: Traditional",
#     "AF-AF: Secure",
#     "AF-N: Traditional",
#     "AF-N: Secure",
# ]
# boxPlotMaker._one_box_plot(
#     X_class_1,
#     X_class_2,
#     9,
#     "Iris - Normal point box plot",
#     normal_point_x_labels,
#     "Iris_normal_point_box_plot",
# )

# boxPlotMaker._one_box_plot(
#     X_class_2,
#     X_class_1,
#     9,
#     "Iris - AF point box plot",
#     af_point_x_labels,
#     "Iris_af_point_box_plot",
# )
t0 = time.time()
boxPlotMaker.make_all_box_plots(X_class_1, X_class_2, 9, "Iris", multithreaded=True)
t1 = time.time()
total_time_1 = t1 - t0


t0 = time.time()
boxPlotMaker.make_all_box_plots(X_class_1, X_class_2, 9, "Iris", multithreaded=False)
t1 = time.time()
total_time_2 = t1 - t0

print(f"Total execution time multithreaded: {total_time_1}")
print(f"Total execution time NOT multithreaded: {total_time_2}")
