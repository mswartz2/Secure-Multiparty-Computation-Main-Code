from sklearn.datasets import load_iris
from DistanceGraphMaker import DistanceGraphMaker
import os

# get iris dataset
X_class, y_class = load_iris().data, load_iris().target

# we just want binary classification
X_class = X_class[:100]
y_class = y_class[:100]

# separate classes
X_class_1 = X_class[:50]
y_class_1 = y_class[:50]
X_class_2 = X_class[50:]
y_class_2 = y_class[50:]

lagrance_maxes = [10 ** (x + 2) for x in range(5)]

distanceGraphsMaker = DistanceGraphMaker()

os.chdir("c:\\Users\\swart\\Desktop\\secure-mpc-main\\distance_graphs\\iris_graphs\\")

distanceGraphsMaker.makeNormalizedGraph(
    X_class_1[0],
    X_class_1[1:],
    y_class_1[1:],
    "Iris - Normal vs Normal",
)
