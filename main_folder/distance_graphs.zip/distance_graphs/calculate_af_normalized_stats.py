import os
import sys
import numpy as np

sys.path.append(os.getcwd())

from ecgPreprocessedData.PickleFileUtils import read_in_pickle_file

saved_data = read_in_pickle_file("distance_graphs\\2017_normalized_distances.pickle")


print(saved_data)

print(f"max: {np.max(saved_data):.3}")
print(f"mean: {np.mean(saved_data):.3}")
