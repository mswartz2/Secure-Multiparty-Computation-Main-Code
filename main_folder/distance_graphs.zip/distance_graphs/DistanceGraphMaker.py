from math import sqrt
import numpy as np
import matplotlib.pyplot as plt
from textwrap import wrap
from sklearn.preprocessing import normalize

from os import chdir, getcwd
import sys

sys.path.append(getcwd())
from distance_graphs.DistanceCalculator import DistanceCalculator


class DistanceGraphMaker(DistanceCalculator):
    def compare_dist_graph(
        self,
        test_row,
        point_arr_x,
        point_arr_y,
        dataset_name,
        max_x_lagrange,
        secure_color,
        centralized_color,
        save_fig_path="",
    ):
        norm_dists = self._get_distances_one_to_many_normal(test_row, point_arr_x)
        secure_dists = self._get_distances_one_to_many_secure(
            test_row, point_arr_x, point_arr_y, max_x_lagrange
        )

        N = len(point_arr_x)
        ind = np.arange(N)
        width = 0.35

        fig = plt.figure()
        ax = fig.add_subplot(111)

        normRects = ax.bar(ind, norm_dists, width, color=centralized_color)
        secureRects = ax.bar(ind + width, secure_dists, width, color=secure_color)

        avg_norm = np.mean(norm_dists)
        avg_secure = np.mean(secure_dists)

        textstr = "\n".join(
            (
                f"Avg. Traditional Distance: {avg_norm}",
                f"Avg. Secure Distance: {avg_secure}",
            )
        )

        # these are matplotlib.patch.Patch properties
        props = dict(boxstyle="round", facecolor="wheat", alpha=0.5)

        # place a text box in upper left in axes coords
        ax.text(
            0.05,
            0.95,
            textstr,
            transform=ax.transAxes,
            fontsize=10,
            verticalalignment="top",
            bbox=props,
        )

        ax.set_ylabel("Distance")
        ax.set_xlabel("Sample number")
        ax.set_title(
            "\n".join(
                wrap(
                    f"Traditional vs. Secure Euclidean Distances - {dataset_name} Dataset - Max x coordinate: {max_x_lagrange}",
                    60,
                )
            )
        )

        ax.legend(
            (normRects[0], secureRects[0]), ("Normal", "Secure"), loc="upper right"
        )

        if save_fig_path != "":
            plt.savefig(save_fig_path)
        else:
            plt.show()

    def graphDifferencesInDistance(
        self,
        test_row,
        point_arr_x,
        point_arr_y,
        dataset_name,
        max_x_lagrange,
        line_color,
        save_fig_path="",
    ):
        norm_dists = self._get_distances_one_to_many_normal(test_row, point_arr_x)
        secure_dists = self._get_distances_one_to_many_secure(
            test_row, point_arr_x, point_arr_y, max_x_lagrange
        )

        differences = []
        for x1, x2 in zip(norm_dists, secure_dists):
            diff = x1 - x2
            differences.append(diff)

        N = len(point_arr_x)
        ind = np.arange(N)
        width = 0.35

        fig = plt.figure()
        ax = fig.add_subplot(111)

        diffRects = ax.bar(ind, differences, width, color=line_color)

        avg_differences = np.mean(np.absolute(differences))

        textstr = "\n".join((f"Avg. Absolute Difference: {avg_differences}",))

        # these are matplotlib.patch.Patch properties
        props = dict(boxstyle="round", facecolor="wheat", alpha=0.5)

        # place a text box in upper left in axes coords
        ax.text(
            0.05,
            0.95,
            textstr,
            transform=ax.transAxes,
            fontsize=10,
            verticalalignment="top",
            bbox=props,
        )

        ax.set_ylabel("Difference in Distance")
        ax.set_xlabel("Sample number")
        ax.set_title(
            "\n".join(
                wrap(
                    f"Secure Distance Subtracted from Normal Distance - {dataset_name} Dataset - Max x coordinate: {max_x_lagrange}",
                    60,
                )
            )
        )

        ax.legend(loc="upper right")

        if save_fig_path != "":
            plt.savefig(save_fig_path)
        else:
            plt.show()

    def graphNormlizedDifferences(
        self,
        test_point,
        X_class,
        y_class,
        dataset_name,
        max_x_lagrange=100000,
        save_fig_path="",
    ):

        norm_dists = self._get_distances_one_to_many_normal(test_point, X_class)
        secure_dists = self._get_distances_one_to_many_secure(
            test_point, X_class, y_class, max_x_lagrange
        )

        differences = []
        for x1, x2 in zip(norm_dists, secure_dists):
            diff = x1 - x2
            differences.append(abs(diff))

        normalized_differences = normalize([differences]).flatten()

        N = len(X_class)
        ind = np.arange(N)
        width = 0.35

        fig = plt.figure()
        ax = fig.add_subplot(111)

        # diffRects = ax.bar(ind, normalized_differences, width, color="royalblue")

        ax.scatter(ind, normalized_differences)

        ax.set_ylabel("Difference of Normalized Euclidean Distances")
        ax.set_xlabel("Sample number")

        y_ticks = np.arange(0, max(normalized_differences), 0.02)
        # ax.set_yticks([0, 0.02, 0.04, 0.06, 0.08, 0.1])
        ax.set_yticks(y_ticks)
        ax.set_ylim(0, max(normalized_differences))

        if save_fig_path != "":
            plt.savefig(save_fig_path)
        else:
            plt.show()

        return normalized_differences

    def makeGraphs(
        self,
        test_point,
        X_class,
        y_class,
        x_lagrange_maxs,
        dataset_name,
        secure_color,
        centralized_color,
        difference_color,
    ):

        file_names_compare = [
            f"compare_{dataset_name}_{str(x)}" for x in x_lagrange_maxs
        ]
        file_names_diffs = [f"diffs_{dataset_name}{str(x)}" for x in x_lagrange_maxs]

        for i in range(len(x_lagrange_maxs)):
            self.graphDifferencesInDistance(
                test_point,
                X_class,
                y_class,
                dataset_name,
                x_lagrange_maxs[i],
                difference_color,
                file_names_diffs[i],
            )
            self.compare_dist_graph(
                test_point,
                X_class,
                y_class,
                dataset_name,
                x_lagrange_maxs[i],
                secure_color,
                centralized_color,
                file_names_compare[i],
            )

    def makeNormalizedGraph(
        self, test_point, X_class, y_class, dataset_name, max_x_lagrange=100000
    ):

        save_file = f"NormalizedDifferences_{dataset_name}"
        normalized_dists = self.graphNormlizedDifferences(
            test_point, X_class, y_class, dataset_name, max_x_lagrange, save_file
        )
        return normalized_dists
