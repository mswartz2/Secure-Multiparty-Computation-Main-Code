from os import chdir, getcwd
import sys

sys.path.append(getcwd())
from basic_networking.client import Client
from basic_networking.server import Server
from math import sqrt


class DistanceCalculator:
    # get list of euclidean distances normal
    def _euclidean_distance_normal(self, row1, row2):
        distance = 0.0
        for i in range(len(row1)):
            distance += (row1[i] - row2[i]) ** 2
        return sqrt(distance)

    def _get_distances_one_to_many_normal(self, test_point, point_arr):
        distances = []
        for point in point_arr:
            dist = self._euclidean_distance_normal(test_point, point)
            distances.append(dist)
        return distances

    def _get_distances_one_to_many_secure(
        self, test_point, point_arr_x, point_arr_y, max_x_lagrange
    ):
        alice = Client()
        server = Server()
        server.set_features_labels(point_arr_x, point_arr_y)
        distances_and_labels = alice.get_distances_and_labels(
            test_point, server, rand_range=max_x_lagrange
        )
        distances = list(zip(*distances_and_labels))[0]

        return distances
